using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DgChaos
{
    public partial class Form1 : Form
    {
        Random rng = new Random();

        public Form1()
        {
            InitializeComponent();

            this.Text = "CHAOS PORTAL";
            this.BackColor = Color.FromArgb(74, 0, 247);
            this.ForeColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(600, 400);

            Label chaosLabel = new Label();
            chaosLabel.Text = "Choose Your Chaos:";
            chaosLabel.ForeColor = Color.White;
            chaosLabel.BackColor = Color.Transparent;
            chaosLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            chaosLabel.AutoSize = true;
            chaosLabel.Location = new Point(200, 20);
            this.Controls.Add(chaosLabel);

            AddButton("🛠 Open Task Manager", 60, (s, e) => {
                if (MessageBox.Show("Open Task Manager?", "Prompt", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    Process.Start("taskmgr");
            });

            AddButton("🎲 Do Something Random", 110, (s, e) => DoRandomThing());

            AddButton("📤 Open Discord", 160, (s, e) => Process.Start("https://discord.com/app"));

            AddButton("📸 Take Screenshot", 210, (s, e) => {
                Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                Graphics g = Graphics.FromImage(bmp);
                g.CopyFromScreen(0, 0, 0, 0, bmp.Size);
                bmp.Save(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "screenshot.png"));
                MessageBox.Show("Screenshot saved to Desktop.");
            });

            AddButton("❌ Exit", 260, (s, e) => Application.Exit());
        }

        private void AddButton(string text, int y, EventHandler action)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Size = new Size(250, 40);
            btn.Location = new Point(175, y);
            btn.Click += action;
            this.Controls.Add(btn);
        }

        private void DoRandomThing()
        {
            int choice = rng.Next(20);
            switch (choice)
            {
                case 0: MessageBox.Show("omg stop clicking"); break;
                case 1: Process.Start("notepad"); break;
                case 2: Process.Start("calc"); break;
                case 3: MessageBox.Show("Your PC is being watched."); break;
                case 4: BackColor = Color.Red; break;
                case 5: Text = "System Breach Detected!"; break;
                case 6: MessageBox.Show("Imagine this was a virus."); break;
                case 7: MessageBox.Show("Too late to turn back now."); break;
                case 8: Process.Start("https://www.youtube.com/watch?v=dQw4w9WgXcQ"); break;
                case 9: TopMost = !TopMost; break;
                case 10: Size = new Size(700, 500); break;
                case 11: MessageBox.Show("Error: You are awesome."); break;
                case 12: MessageBox.Show("Your fate has been sealed."); break;
                case 13: MessageBox.Show("Button mashed."); break;
                case 14: this.Visible = false; Timer t = new Timer(); t.Interval = 2000; t.Tick += (s, e) => { this.Visible = true; t.Stop(); }; t.Start(); break;
                case 15: MessageBox.Show("YOU ARE AN IDIOT!!!!"); Process.Start("https://www.youtube.com/watch?v=48rz8udZBmQ"); break;
                case 16: Process.Start("explorer"); break;
                case 17: this.Location = new Point(rng.Next(500), rng.Next(300)); break;
                case 18: Process.Start("https://open.spotify.com/track/3YbSGiHeitQQLDekfUXdQF"); break;
                case 19: MessageBox.Show("🌀 INITIATING RANDOMNESS 🌀"); break;
            }
        }
    }
}