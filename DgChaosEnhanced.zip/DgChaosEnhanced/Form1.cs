
using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DgChaosEnhanced
{
    public partial class Form1 : Form
    {
        Random rng = new Random();

        public Form1()
        {
            InitializeComponent();

            this.Text = "CHAOS PORTAL";
            this.BackColor = Color.FromArgb(74, 0, 247);
            this.ForeColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(600, 400);

            Label chaosLabel = new Label();
            chaosLabel.Text = "Choose Your Chaos:";
            chaosLabel.ForeColor = Color.White;
            chaosLabel.BackColor = Color.Transparent;
            chaosLabel.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            chaosLabel.AutoSize = true;
            chaosLabel.Location = new Point(180, 20);
            this.Controls.Add(chaosLabel);

            AddButton("🛠 Open Task Manager", new Point(200, 80), () => {
                if (MessageBox.Show("Open Task Manager?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Process.Start("taskmgr");
                }
            });

            AddButton("🎲 Do Random Chaos", new Point(200, 130), () => DoRandomThing());

            AddButton("📷 You Are An Idiot", new Point(200, 180), () => {
                MessageBox.Show("YOU ARE AN IDIOT 😂😂😂");
                Process.Start("https://www.youtube.com/watch?v=48rz8udZBmQ");
            });

            AddButton("💬 Open Discord", new Point(200, 230), () => {
                Process.Start("https://discord.com");
            });

            AddButton("❌ Exit", new Point(200, 280), () => Application.Exit());
        }

        private void AddButton(string text, Point location, Action action)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Size = new Size(200, 40);
            btn.Location = location;
            btn.Click += (s, e) => action();
            this.Controls.Add(btn);
        }

        private void DoRandomThing()
        {
            int choice = rng.Next(20);
            switch (choice)
            {
                case 0: MessageBox.Show("Your PC is being watched."); break;
                case 1: Process.Start("notepad"); break;
                case 2: Process.Start("calc"); break;
                case 3: MessageBox.Show("You pressed the button!!!"); break;
                case 4: this.BackColor = Color.Red; break;
                case 5: this.Text = "CHAOS INTENSIFIES"; break;
                case 6: MessageBox.Show("Imagine this was a virus."); break;
                case 7: MessageBox.Show("Too late to turn back now."); break;
                case 8: Process.Start("https://www.youtube.com/watch?v=dQw4w9WgXcQ"); break;
                case 9: TopMost = !TopMost; break;
                case 10: this.Size = new Size(800, 600); break;
                case 11: MessageBox.Show("ERROR: You are awesome."); break;
                case 12: MessageBox.Show("Your fate has been sealed."); break;
                case 13: MessageBox.Show("This app is pure chaos."); break;
                case 14: Process.Start("mspaint"); break;
                case 15: MessageBox.Show("💀💀💀💀💀"); break;
                case 16: Process.Start("https://open.spotify.com/track/3YbSGiHeitQQLDekfUXdQF"); break;
                case 17: MessageBox.Show("Don't click again."); break;
                case 18: MessageBox.Show("You've been warned."); break;
                case 19: MessageBox.Show("Chaos complete."); break;
            }
        }
    }
}
